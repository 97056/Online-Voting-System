<?php include "header.php";
session_start();
if (isset($_SESSION['SESS_NAME'])!="") {
	header("Location: voter.php");
}
?>
<?php global $msg; echo $msg;?>
<img src="india.jpg" height="500" width="1500"><br><br>
<p><legend><font color="red"><h4>How To Register to Vote</h4> 
<font color="blue">General Voter - Any Indian citizen residing within the country, who has attained the age of 18, can enroll himself/herself as General Voter<br>
    Fill Form 6 online at<a href="https://www.nvsp.in/."> https://www.nvsp.in/.</a> Copies of necessary documents should also be uploaded.<br>
    <font color="red"><h4>How to check if you are registered to vote?</h4>
<font color="blue">Visit <a href="https://electoralsearch.in/">https://electoralsearch.in/</a> to see your if you are registered to vote. If your name appears in the list, you are eligible to vote, otherwise, you need to register at https://www.nvsp.in/

    <font color="red"><h4>Requirements for registering to vote</h4>
    <font color="blue">You can enroll as a Voter if you:<br><br>
  <img src="Voting system.jpg" height="500" width="1000"><br><br>
1.Are an Indian citizen<br>
2.Have attained the age of 18 years on the qualifying date i.e. 1st of January of the year of revision of electoral roll<br>
3.Are ordinarily resident of the part/polling area of the constituency where you want to be enrolled.<br><br>
4.Are not disqualified to be enrolled as an elector<br><br>
If you meet the above criteria please download Voter Helpline App (android) or (iOS Version from here)or visit <a href=" https://voterportal.eci.gov.in/"> https://voterportal.eci.gov.in/ </a>to register online.

<font color="red"><h4>How to register to vote offline</h4>

<font color="blue">1.You can also enroll offline. Fill two copies of Form 6.This form is also available free of cost in offices of Electoral Registration Officers / Assistant Electoral Registration Officers and Booth Level Officers.<br>
 2.The application accompanied by copies of the relevant documents can be filed in person before the concerned Electoral Registration Officer / Assistant Electoral Registration Officer or sent by post addressed to him or can be handed over to the Booth Level Officer of your polling area.<br>
 3.Call 1950 for any help.<br>

 <font color="red"><h4>1. Why should you vote?</h4>
 <font color="blue">India is the largest democracy in the world. The right to vote and more
importantly the exercise of franchise by the eligible citizens is at the heart of
every democracy. We, the people, through this exercise of our right to vote
have the ultimate power to shape the destiny of country by electing our
representatives who run the Government and take decisions for the growth,
development and benefit of all the citizens.
<font color="red"><h4>2. Who can vote?</h4>
<font color="blue">All citizens of India who are 18 years of age as on 1st January of the
year for which the electoral roll is prepared are entitled to be registered as a
voter in the constituency where he or she ordinarily resides. Only persons
who are of unsound mind and have been declared so by a competent court or
disqualified due to ‘Corrupt Practices’ or offences relating to elections are not
entitled to be registered in the electoral rolls.
<font color="red"><h4>3. What is an electoral roll?</h4>
<font color="blue">An electoral roll is a list of all eligible citizens who are entitled to cast
their vote in an election. The electoral rolls are prepared Assembly
Constituency wise. An electoral roll for any Assembly Constituency is subdivided into parts corresponding with the polling booths. The Election
Commission of India has decided to generally have a maximum of 1200
electors per booth. The polling booths are so set up that no voter should
ordinarily travel more than 2 kms. to reach the polling booth. Normally, one
part will correspond with one polling booth.<br><br>
<font color="blue"> To exercise your franchise, the first and foremost requirement is that
your name should be in the electoral roll. Without your name registered in the
relevant part for the area where you ordinarily reside in the Assembly
Constituency, you will not be allowed to exercise your franchise. Therefore, it
is your duty to find out whether your name has been registered or not. 

<font color="red"><h4>Voting Proposal</h4>

<img src="online-voting.png" height="500" width="1000"><br><br>
<font color="blue">An online voting is initiated by a proposal for voting which states the subject of the voting. The proposal is sent by email to the membership mailing list and has to include exact and complete information what is voted upon. Only the information which is directly included in the mail sent as voting proposal is subject of the voting.<br>

The voting proposal email has to explicitly be marked as voting proposal by starting the email subject line with one of the following strings, which are not case-sensitive:<br><br>

1.Voting Proposal<br>
2.Vote Proposal<br>
3.Member Proposal<br><br>
Any active member can initiate a voting by sending a voting proposal.<br><br>

The member who has initiated a vote can retract the voting proposal by sending an email to the membership list stating the intention to retract the proposal.<br><br>

A proposal can only be retracted within the discussion period.<br><br>

<font color="red"><h4>Discussion Period</h4>
<font color="blue">The discussion period begins on the date the membership mailing list receives the voting proposal. Unless specified otherwise in the procedures for the specific type of vote (see: Types of Votes), the discussion period lasts for two weeks. The discussion period should be used to discuss the voting and form opinions about the options which are available for voting.<br><br>

<font color="red"><h4>Start of Voting</h4>
<font color="blue">When the discussion period has finished the voting is started by sending ballots to all active members. The ballots should include the text of the proposal which is voted about.<br><br>

<font color="red"><h4> Voting Period</h4>
<font color="blue">The voting period is started by sending out the ballots. Unless specified otherwise in the procedures for the specific type of vote (see: Types of Votes), the voting period lasts for two weeks. During the voting period the active members cast their votes. Only votes cast within the voting period are considered for the results of the voting.<br><br>

<font color="red"><h4>End of Voting</h4>
<font color="blue">After the voting period all cast votes are counted and the results of the voting are published.<br><br>

The results of a vote are published to the KDE e.V. membership by sending them to the membership mailing list. They have to include the number of persons permitted to vote, the total number of votes, and the number of votes for each available voting option. The results should also include a statement, if the voting was valid according to section 5.<br><br>
<img src="vote.png" height="500" width="1000"><br><br>
</font></legend>
    <p>&nbsp;&nbsp;</p>
 <?php include "footer.php";?>
